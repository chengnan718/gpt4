---
name: "\U0001F4C4 Documentation"
about: An issue related to the GPT4All documentation
labels: ["documentation"]
---

### Documentation

<!-- Please describe the issue with the documentation as clearly as possible. -->
