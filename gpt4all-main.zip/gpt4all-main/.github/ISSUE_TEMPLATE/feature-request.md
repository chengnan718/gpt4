---
name: "\U0001F680 Feature Request"
about: Submit a proposal/request for a new GPT4All feature
title: "[Feature] Feature request title..."
labels: ["enhancement"]
---

### Feature Request

<!-- A clear and concise description of the feature proposal. -->
